"""Custom theme plugin for novelibre.

Applies the 'awdark' theme, if available. 

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_dark
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
import shutil
from tkinter import messagebox

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon

DEFAULT_COLORS = dict(
    color_1st_edit='#8b6508',  # DarkGoldenrod4
    color_2nd_edit='#cd950c',  # DarkGoldenrod3
    color_before_schedule='#32cd32',  # lime green
    color_behind_schedule='#ff00ff',  # magenta
    color_chapter='#008b00',  # green4
    color_comment_tag='#fffacd',  # lemon chiffon
    color_done='#eead0e',  # DarkGoldenrod2
    color_draft='#000000',  # black
    color_highlight='#e6e6fa',  # lavender
    color_inactive_bg='#d3d3d3',  # light gray
    color_locked_bg='#696969',  # dim gray
    color_locked_fg='#d3d3d3',  # light gray
    color_modified_bg='#ffc125',  # goldenrod1
    color_modified_fg='#b03060',  # maroon
    color_notes_bg='#fffacd',  # lemon chiffon
    color_notes_fg='#000000',  # black
    color_note_tag='#ffe4c4',  # bisque
    color_on_schedule='#000000',  # black
    color_outline='#9932cc',  # dark orchid
    color_separator='#d3d3d3',  # light gray
    color_stage='#ff0000',  # red
    color_status_error_bg='#ff0000',  # red
    color_status_error_fg='#ffffff',  # white
    color_status_notification_bg='#ffff00',  # yellow
    color_status_notification_fg='#000000',  # black
    color_status_success_bg='#008b00',  # green4
    color_status_success_fg='#ffffff',  # white
    color_text_bg='#ffffff',  # white
    color_text_fg='#000000',  # black
    color_unused='#808080',
    color_xml_tag='#6495ed',  # cornflower blue
)


class Plugin(PluginBase):
    VERSION = '5.0.2'
    API_VERSION = '5.63'
    DESCRIPTION = 'Applies the tcl awdark theme, if available'
    URL = 'https://github.com/peter88213/nv_dark'
    HELP_SITE = 'https://peter88213.github.io/nv_dark'
    HELP_PAGE = 'help'

    COLORS = dict(
        color_1st_edit='#eead0e',  # DarkGoldenrod2
        color_2nd_edit='#cd950c',  # DarkGoldenrod3
        color_before_schedule='#2e8b57',  # sea green
        color_behind_schedule='#ff6347',  # tomato
        color_chapter='#7fff00',  # chartreuse
        color_comment_tag='#8b7e66',  # wheat4
        color_done='#8b6508',  # DarkGoldenrod4
        color_draft='#ffffff',  # white
        color_highlight='#2f4f4f',  # dark slate gray
        color_inactive_bg='#394341',
        color_locked_bg='#696969',  # dim gray
        color_locked_fg='#d3d3d3',  # light gray
        color_modified_bg='#ffc125',  # goldenrod1
        color_modified_fg='#b03060',  # maroon
        color_notes_bg='#8b7e66',  # wheat4
        color_notes_fg='#ffffff',  # white
        color_on_schedule='#ffffff',  # white
        color_outline='#ee7ae9',  # orchid2
        color_separator='#000000',  # black
        color_stage='#ff6347',  # tomato
        color_status_error_bg='#ff0000',  # red
        color_status_error_fg='#ffffff',  # white
        color_status_notification_bg='#ffff00',  # yellow
        color_status_notification_fg='#000000',  # black
        color_status_success_bg='#00ff00',  # green
        color_status_success_fg='#ffffff',  # white
        color_text_bg='#33393b',
        color_text_fg='#d3d3d3',  # light gray
        color_unused='#808080',
        color_xml_tag='#6495ed',  # cornflower blue
    )

    def install(self, model, view, controller):
        super().install(model, view, controller)
        THEME_DIR = '.novx/themes'
        THEME_PACKAGE = 'awthemes'
        THEME = 'awdark'

        homeDir = str(Path.home()).replace('\\', '/')
        self.themePath = f'{homeDir}/{THEME_DIR}/{THEME_PACKAGE}'
        self._ui.root.tk.call(
            'lappend',
            'auto_path',
            self.themePath,
        )
        self._ui.root.tk.call('package', 'require', THEME)
        self._ui.guiStyle.theme_use(THEME)

        prefs = self._ctrl.get_preferences()
        colorsChanged = False
        for color in self.COLORS:
            if prefs[color] != self.COLORS[color]:
                prefs[color] = self.COLORS[color]
                colorsChanged = True
        if colorsChanged:
            messagebox.showinfo(
                'Dark theme installer',
                'Please restart novelibre now to apply changed colors.'
            )


        self._add_help_menu_entry('nv_dark plugin help')

    def uninstall(self):
        prefs = self._ctrl.get_preferences()
        for color in DEFAULT_COLORS:
            prefs[color] = DEFAULT_COLORS[color]
        shutil.rmtree(self.themePath, ignore_errors=True)
