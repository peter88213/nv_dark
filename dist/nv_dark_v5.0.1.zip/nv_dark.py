"""Custom theme plugin for novelibre.

Applies the 'awdark' theme, if available. 

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_dark
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
import shutil
from tkinter import messagebox

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon

DEFAULT_COLORS = dict(
    color_1st_edit='DarkGoldenrod4',
    color_2nd_edit='DarkGoldenrod3',
    color_before_schedule='lime green',
    color_behind_schedule='magenta',
    color_chapter='green',
    color_comment_tag='lemon chiffon',
    color_done='DarkGoldenrod2',
    color_draft='black',
    color_highlight='lavender',
    color_inactive_bg='light gray',
    color_locked_bg='dim gray',
    color_locked_fg='light gray',
    color_modified_bg='goldenrod1',
    color_modified_fg='maroon',
    color_notes_bg='lemon chiffon',
    color_notes_fg='black',
    color_note_tag='bisque',
    color_on_schedule='black',
    color_outline='dark orchid',
    color_separator='light gray',
    color_stage='red',
    color_status_error_bg='red',
    color_status_error_fg='white',
    color_status_notification_bg='yellow',
    color_status_notification_fg='black',
    color_status_success_bg='green',
    color_status_success_fg='white',
    color_text_bg='white',
    color_text_fg='black',
    color_unused='gray',
    color_xml_tag='cornflower blue',
)


class Plugin(PluginBase):
    VERSION = '5.0.1'
    API_VERSION = '5.63'
    DESCRIPTION = 'Applies the tcl awdark theme, if available'
    URL = 'https://github.com/peter88213/nv_dark'
    HELP_SITE = 'https://peter88213.github.io/nv_dark'
    HELP_PAGE = 'help'

    COLORS = dict(
        color_1st_edit='DarkGoldenrod2',
        color_2nd_edit='DarkGoldenrod3',
        color_before_schedule='sea green',
        color_behind_schedule='tomato',
        color_chapter='chartreuse',
        color_comment_tag='wheat4',
        color_done='DarkGoldenrod4',
        color_draft='white',
        color_highlight='dark slate gray',
        color_inactive_bg='#394341',
        color_locked_bg='dim gray',
        color_locked_fg='light gray',
        color_modified_bg='goldenrod1',
        color_modified_fg='maroon',
        color_notes_bg='wheat4',
        color_notes_fg='white',
        color_on_schedule='white',
        color_outline='orchid2',
        color_separator='black',
        color_stage='tomato',
        color_status_error_bg='red',
        color_status_error_fg='white',
        color_status_notification_bg='yellow',
        color_status_notification_fg='black',
        color_status_success_bg='green',
        color_status_success_fg='white',
        color_text_bg='#33393b',
        color_text_fg='light gray',
        color_unused='gray',
        color_xml_tag='cornflower blue',
    )

    def install(self, model, view, controller):
        super().install(model, view, controller)
        THEME_DIR = '.novx/themes'
        THEME_PACKAGE = 'awthemes'
        THEME = 'awdark'

        homeDir = str(Path.home()).replace('\\', '/')
        self.themePath = f'{homeDir}/{THEME_DIR}/{THEME_PACKAGE}'
        self._ui.root.tk.call(
            'lappend',
            'auto_path',
            self.themePath,
        )
        self._ui.root.tk.call('package', 'require', THEME)
        self._ui.guiStyle.theme_use(THEME)

        prefs = self._ctrl.get_preferences()
        colorsChanged = False
        for color in self.COLORS:
            if prefs[color] != self.COLORS[color]:
                prefs[color] = self.COLORS[color]
                colorsChanged = True
        if colorsChanged:
            messagebox.showinfo(
                'Dark theme installer',
                'Please restart novelibre now to apply changed colors.'
            )


        self._add_help_menu_entry('nv_dark plugin help')

    def uninstall(self):
        prefs = self._ctrl.get_preferences()
        for color in DEFAULT_COLORS:
            prefs[color] = DEFAULT_COLORS[color]
        shutil.rmtree(self.themePath, ignore_errors=True)
